import {
    stripe
} from 'stripe';

import {
    config
} from 'config';

stripe = stripe(process.env.STRIPE_KEY || config.get('STRIPE_KEY'));


//-------------- basic stripe functions ----------------


let createCustomer = (payload) => {
     return new Promise((resolve, reject) => {
        stripe.customers.create({
            email: payload.email

          }, (err, customer) => {
              if (err) {
                reject(err);
              }
              resolve(customer);
          });
     });
};


let updateCustomer = (payload) => {
    return new Promise((resolve, reject) => {
        stripe.customers.update(
            payload.customerId,
            payload.dataObject,
              (err, customer) => {
                if (err) {
                    reject(err);
                  }
                  resolve(customer);     
             }
          );
    });
};


let retrieveCustomer = (payload) => {
    return new Promise((resolve, reject) => {
        stripe.customers.retrieve(
            payload.customerId,
            (err, customer) => {
                if (err) {
                    reject(err);
                  }
                  resolve(customer);  
            }
          );    
    });
};

let addPaymentCard = (payload) => {
    return new Promise((resolve, reject) => {
        stripe.customers.createSource(
            payload.customerId,
            {
              source: payload.token,
            },
            (err, card) => {
                if (err) {
                    reject(err);
                  }
                  resolve(card);
            }
          );        
    });
};


let deletePaymentCard = (payload) => {
    return new Promise((resolve, reject) => {
        stripe.customers.deleteSource(
            payload.customerId,
            payload.cardId,
            (err, confirmation) => {
                if (err) {
                    reject(err);
                  }
                  resolve(confirmation); 
            }
          );
    });
};



let createCharge = (payload) => {
    return new Promise((resolve, reject) => {
        stripe.charges.create({
            amount: payload.amount,
            currency: payload.currency,
            customer: payload.customerId
          }, (err, charge) => {
            if (err) {
                reject(err);
              }
              resolve(charge);  
        });
    });
};


let retrieveCharge = (payload) => {
    return new Promise((resolve, reject) => {
        stripe.charges.retrieve(
            payload.chargeId,
            (err, charge) => {
                if (err) {
                    reject(err);
                  }
                  resolve(charge);
            }
          );
    });
};