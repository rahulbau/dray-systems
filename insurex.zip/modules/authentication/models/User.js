let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let UserSchema = new Schema({
    userEmail: {
        type: String,
        default: '',
        unique: true
    },
    userPassword: {
        type: String,
        default: ''
    },
    userFirstName: {
        type: String,
        default: ''
    },
    userLastName: {
        type: String,
        default: ''
    },
    username: {
        type: String,
        default: ''
    },
    deactivate: {
        type: Number,
        default: 0
    },
    role: {
        type: Number,
        default: 1
    },
    accessTokens: [String],
    userPhone: {
        type: String,
        default: '',
    },
    uid: {
        type: String,
        unique: true
    },
    emailVarified: {
        type: Number,
        default: 0,
    },
    phoneVarified: {
        type: Number,
        default: 0,
    },
    userCountry: {
        type: String,
        default: '',
    },
    regionCode: {
        type: String,
        default: ''
    },
    userDob: {
        type: String,
        default: '',
    },
    bloodGroup: String,
    height: String,
    weight: String,
    userPic: String,
    addiction: String,
    foodHabit: String,
    appetite: String,
    frequencyOfStools: String,
    micturition: String,
    sleep: String,
    medications: String,
    spectacle: String,
    dependent: Number,
    gender: String,
    maritalStatus: String,
    numberOfDependents: Number,
    fatherName: String,
    motherName: String,
    identificationMark: String,
    surveyorNumber: String,
    nativeVillage: String,
    district: String,
    state: String,
    idProof: String,
    idProofNumber: String,
    idProofImage: String,
    communicationAddress: String,
    permanentAddress: String,
    occupation: String,
    occupationalAddress: String,
    qualification: String,
    extraCurricular: String,
    clubMembership: String,
    emergencyContactPerson: String,
    familyDoctor: String,
    familyDoctorAddress: String,
    relationUid : String,
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('User', UserSchema);