const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let OTPSchema = new Schema({
       userId: Schema.Types.ObjectId,
       otp : String,
       type:Number,   // 2- phone ,1- email 
       userEmail : String, 
       createdAt: { type: Date, default: Date.now }

});

module.exports = mongoose.model('OTP', OTPSchema);