const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const policySchema = new Schema({
       userId: Schema.Types.ObjectId,
       insuranceCompany : String,
       premiumAmount:String,   
       policyType : String, 
       tpa : String, 
       commulativeBonusAmount : String, 
       nomineeName : String,
       policyNumber: String, 
       policyDocument: String,
       policyStartDate : String,
       expirationDate : String,
       policyRenewalDate : String,
       interval : String,
       type : Number,
       intermidiateryNumber: String,
       createdAt: { type: Date, default: Date.now }
});


module.exports = mongoose.model('insurancePolicy', policySchema);