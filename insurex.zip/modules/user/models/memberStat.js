const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const memberStatSchema = new Schema({
       userId: Schema.Types.ObjectId,
       heartRate : String,
       bloodPressure:String,   
       respiratoryRate : String, 
       bloodSugar : String, 
       temperature : String, 
       weight : String, 
       height : String, 
       pulseRate : String, 
       waistSize : String, 
       wristSize : String, 
       abdomenSize : String, 
       chestSize : String, 
       createdAt: { type: Date, default: Date.now }

});


module.exports = mongoose.model('MemberStat', memberStatSchema);