const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const labTestSchema = new Schema({
       userId: Schema.Types.ObjectId,
       testName : String,
       prescriberName:String,   
       healthCareProvider : String, 
       doctorInCharge : String, 
       labName : String, 
       labTechnicianName : String,
       testResult: String, 
       othersResult: String, 
       createdAt: { type: Date, default: Date.now }
});


module.exports = mongoose.model('LabTest', labTestSchema);