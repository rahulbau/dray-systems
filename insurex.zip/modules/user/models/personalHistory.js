const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let personalHistorySchema = new Schema({
    userId: Schema.Types.ObjectId,
    icdCode: String,
    nameOfDisease: String,
    duration: String,
    diseaseImage: String,
    procedureCode: String,
    procedureDetails: String,
    procedureImage: String,
    medicineCode: String,
    medicineName: String,
    medicineImage: String,
    createdAt: { type: Date, default: Date.now }

});

module.exports = mongoose.model('personalHistory', personalHistorySchema);