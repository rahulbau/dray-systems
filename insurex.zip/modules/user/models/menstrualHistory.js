const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let menstrualHistorySchema = new Schema({
    userId: Schema.Types.ObjectId,
    lmpDetails: String,
    deliveryDetails: String,
    abortionDetails: String,
    firstPeriodDate:String,
    createdAt: { type: Date, default: Date.now }

});

module.exports = mongoose.model('menstrualHistory', menstrualHistorySchema);