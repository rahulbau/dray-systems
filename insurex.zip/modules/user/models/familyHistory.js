const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const familyHistorySchema = new Schema({
       userId: Schema.Types.ObjectId,
       relation : String,
       uid:String,   
       icdCode : String, 
       diseaseName : String, 
       duration : String, 
       procedureCode : String, // optional filled
       procedureDetails: String, 
       medicineCode: String, 
       medicineName: String, 
       //createdAt: { type: Date, default: Date.now }
},{timestamp:true});


module.exports = mongoose.model('familyHistory', familyHistorySchema);