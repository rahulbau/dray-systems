const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let pastHistorySchema = new Schema({
    addiction: String,
    foodHabit: String,
    appetite: String,
    frequencyOfStools: String,
    micturition: String,
    sleep: String,
    medications: String,
    spectacle: String,
    bloodGroup: String,
    userId: String,
    createdAt: {
        type: Date,
        default: Date.now
    }

});

module.exports = mongoose.model('pastHistory', pastHistorySchema);