const db = require('../../../mongoLib');
const {
    logger,
    responses,
    constants
} = require('../../../util');
const User = require('../../authentication/models/User');
const MemberStat = require('../models/memberStat');
const commonFunctions = require("../../../util/commonFunctions");
const LabTest = require('../models/labTest');
const Eth = require('../models/addEth');
const PastHistory = require('../models/pastHistory');
const InsurancePolicy = require('../models/insurancePolicy');
const MenstrualHistory =  require('../models/menstrualHistory');
const FamilyHistory =  require('../models/familyHistory');
const PersonalHistory =  require('../models/personalHistory');

async function addMemberStat(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        req.body.userId = req.body.userId || req.user._id;
        memberStat = new MemberStat(req.body);
        memberStat = await memberStat.save();
        return responses.actionCompleteResponse(res, languageCode, memberStat, "", constants.responseMessageCode.ACTION_COMPLETE);

    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


async function addPersonalHistory(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        req.body.userId = req.body.userId || req.user._id;
        personalHistory = new PersonalHistory(req.body);
        personalHistory = await personalHistory.save();
        return responses.actionCompleteResponse(res, languageCode, personalHistory, "", constants.responseMessageCode.ACTION_COMPLETE);

    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


async function addLabTest(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        req.body.userId = req.body.userId || req.user._id;
        let labTest = new LabTest(req.body);
        labTest = await labTest.save();
        return responses.actionCompleteResponse(res, languageCode, labTest, "", constants.responseMessageCode.ACTION_COMPLETE);

    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}

async function addEth(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        req.body.userId = req.body.userId || req.user._id;
        let addEth = new Eth(req.body);
        addEth = await addEth.save();
        return responses.actionCompleteResponse(res, languageCode, addEth, "", constants.responseMessageCode.ACTION_COMPLETE);
    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


async function getEHR(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        const skip = req.query.offset ? parseInt(req.query.offset) : 0;
        const limit = req.query.limit ? parseInt(req.query.limit) : 20;
        const userEHR = await Eth.find({
            userId: req.query.userId || req.user._id
        }, {}, {
            skip,
            limit
        }).sort({
            createdAt: -1
        });
        return responses.actionCompleteResponse(res, languageCode, userEHR, "", constants.responseMessageCode.ACTION_COMPLETE);
    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


async function editUser(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        const query = {
            _id: req.query.userId || req.user._id
        };
        const options = {
            new: true
        };
        let userData = await User.findOneAndUpdate(query, req.body, options);
        userData = userData.toObject();
        delete userData.userPassword;
        delete userData.accessTokens;
        return responses.actionCompleteResponse(res, languageCode, userData, "", constants.responseMessageCode.ACTION_COMPLETE);

    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}

async function getUser(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        const query = {
            _id: req.query.userId || req.user._id
        };
        let userData = await User.findOne(query);
        userData = userData.toObject();
        delete userData.userPassword;
        delete userData.accessTokens;
        return responses.actionCompleteResponse(res, languageCode, userData, "", constants.responseMessageCode.ACTION_COMPLETE);

    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


async function addPastHistory(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        req.body.userId = req.body.userId || req.user._id;
        let pastHistory = new PastHistory(req.body);
        pastHistory = await pastHistory.save();
        return responses.actionCompleteResponse(res, languageCode, pastHistory, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}

async function addInsurancePolicy(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        req.body.userId = req.body.userId || req.user._id;
        let insurancePolicy = new InsurancePolicy(req.body);
        insurancePolicy = await insurancePolicy.save();
        return responses.actionCompleteResponse(res, languageCode, insurancePolicy, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}


async function addMenstrualHistory(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        req.body.userId = req.body.userId || req.user._id;
        let menstrualHistory = new MenstrualHistory(req.body);
        menstrualHistory = await menstrualHistory.save();
        return responses.actionCompleteResponse(res, languageCode, menstrualHistory, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}


async function addFamilyHistory(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        req.body.userId = req.body.userId || req.user._id;
        let familyHistory = new FamilyHistory(req.body);
        familyHistory = await familyHistory.save();
        return responses.actionCompleteResponse(res, languageCode, familyHistory, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}

async function getUsers(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        const skip = req.query.offset ? parseInt(req.query.offset) : 0;
        const limit = req.query.limit ? parseInt(req.query.limit) : 20;
        const user = await User.find({
            role: 1,
            deactivate : 0
        }, {}, {
            skip,
            limit
        }).sort({
            createdAt: -1
        });
        return responses.actionCompleteResponse(res, languageCode, user, "", constants.responseMessageCode.ACTION_COMPLETE);
    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


async function editInsurancePolicy(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        const query = {
            _id: req.body.id
        };
        const options = {
            new: true
        };
        const updatedData = await InsurancePolicy.findOneAndUpdate(query, req.body, options);
        return responses.actionCompleteResponse(res, languageCode, updatedData, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}


async function editEhr(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        const query = {
            _id: req.body.id
        };
        const options = {
            new: true
        };
        const updatedData = await Eth.findOneAndUpdate(query, req.body, options);
        return responses.actionCompleteResponse(res, languageCode, updatedData, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}


async function editLabTest(req,res){
    const languageCode =req.query.languageCode || 'en';
    try{
        const query = {
            _id: req.body.id
        };
        const options = {
            new: true
        };
        const updatedData = await LabTest.findOneAndUpdate(query, req.body, options);
        return responses.actionCompleteResponse(res, languageCode, updatedData, "", constants.responseMessageCode.ACTION_COMPLETE);
    }catch( e ){
        logger.error(e);
        return responses.sendError(res,languageCode,{},"",e)

    }
}


async function getUserPolicy(req, res) {
    const languageCode = req.query.languageCode || 'en';
    try {
        const skip = req.query.offset ? parseInt(req.query.offset) : 0;
        const limit = req.query.limit ? parseInt(req.query.limit) : 20;
        const policyData = await InsurancePolicy.find({
            userId: req.query.userId || req.user._id
        }, {}, {
            skip,
            limit
        }).sort({
            createdAt: -1
        });
        return responses.actionCompleteResponse(res, languageCode, policyData, "", constants.responseMessageCode.ACTION_COMPLETE);
    } catch (e) {
        logger.error(e);
        return responses.sendError(res, languageCode, {}, "", e);
    }
}


module.exports = {
    addMemberStat,
    addLabTest,
    addEth,
    getEHR,
    editUser,
    getUser,
    addPastHistory,
    addInsurancePolicy,
    addMenstrualHistory,
    addFamilyHistory,
    getUsers,
    addPersonalHistory,
    editInsurancePolicy,
    editEhr,
    editLabTest,
    getUserPolicy
}