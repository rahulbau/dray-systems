const JWT = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');


// const payload = {
//     name : "Manjunath",
//     email: "elvinmanjunath.s@gmail.com"
// }
// const secret = "This is a secret";
// const signOptions = {
//     issuer: 'insurex',
//     expiresIn: '30d'
// };

// const token = JWT.sign(payload, secret, signOptions);
// console.log(token);
       
var decoded = JWT.verify('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiTWFuanVuYXRoIiwiZW1haWwiOiJlbHZpbm1hbmp1bmF0aC5zQGdtYWlsLmNvbSIsImlhdCI6MTU3NDY5OTA3OCwiZXhwIjoxNTc3MjkxMDc4LCJpc3MiOiJpbnN1cmV4In0.VRxl9votqAAh5u5cBp0fMehggIxTJ_J95CjMWivcEVs', 'This is a secret');
console.log(decoded);
 